module.exports = {
    mongoURL:'mongodb://192.168.100.102:27017/name'}


