const fs = require('fs')


 function game(){
     console.log('os')
 }