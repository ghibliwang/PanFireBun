<template>
  <div>
    <Keep-alive>
      <router-view></router-view>
    </Keep-alive>

  </div>
</template>

<script>
  export default {
    
  }
</script>

<style>
*{
  padding: 0;
  margin: 0;
}

</style>