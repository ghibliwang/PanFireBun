<template>
    <div>
        <!-- <h1>{{model.name}}+3</h1> -->
        <P>   士大夫萨芬  这个是我的测试项目，测试项目哈哈哈</P>
        
    </div>
</template>

<script>
    export default {
        data(){
            return{
                model:{
                    name:'king'
                }
            }
        }        
    }
</script>

<style  scoped>



</style>